<!-- header --> 

      <nav class="navbar navbar-expand-md navbar-light" style="background-color: #bec8d1">
      <a class="navbar-brand" href="index.php" style="color:#007bff">UNIVERSAL BANK</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color:black" >Home</a>
              </li>

              
              <li class="nav-item">
                <a class="nav-link" href="customer.php" style="color:black">Customers</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php" style="Color:black">Transaction History</a>
              </li>
          </div>
       </nav>
