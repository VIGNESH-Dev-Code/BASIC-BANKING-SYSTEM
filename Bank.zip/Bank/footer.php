<footer class="text-center mt-5 py-2">
       <h2><a href="index.php">UNIVERSAL BANK</a></h2>
	   <p>&copy Designed & Developed by <a style= "color: #ff4800;font-weight: bold; background: #bec8d1; font-size:15px;"> VIGNESH K</a></p>
      </footer>